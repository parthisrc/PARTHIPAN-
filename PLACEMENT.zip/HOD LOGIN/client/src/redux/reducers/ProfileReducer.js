// Init
const initialState = {};

// Reducer
export default function ProfileReducer(state = initialState, action) {
  switch (action.type) {
    default:
      return state;
  }
}
