export const properties = {
  endpoint: process.env.REACT_APP_ENDPOINT || "http://localhost:3000/api"
};
